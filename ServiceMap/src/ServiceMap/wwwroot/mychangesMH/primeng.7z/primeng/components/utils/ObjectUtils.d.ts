export declare class ObjectUtils {
    equals(obj1: any, obj2: any): boolean;
    resolveFieldData(data: any, field: string): any;
}
